
<div class="container" style="margin-top: 5%;">
        <div class="row">
<form class="border border-primary rounded" style="background:white; margin: auto; width:40%; padding:5% 4%  5% 4%; " action="function.php" name="logindata" method="post" enctype="multipart/form-data">
  <!-- Email input -->
  <div class="form-outline mb-4" style=" margin:auto; width:fit-content;">
  <a href="index.php">
              <img src="assets/img/compnylogo.png" alt="" srcset="" style="height: 40px; ">
  </a>
</div>
  <div class="form-outline mb-4">
  <label class="form-label" for="email">Email address</label>
    <input type="email" id="email" class="form-control" name="email" />
  
  </div>

  <!-- Password input -->
  <div class="form-outline mb-4">
  <label class="form-label" for="password">Password</label>
    <input type="password" id="password" class="form-control" name="password" />
  </div>

  
 

  <!-- Submit button -->
  <button type="submit" class="btn  btn-block mb-4" style="background-color: #042893; color:white;" name="login" >Login</button>
  <p class="text-center">Powered by Aarvi Technolabs</p>
  <!-- Register buttons -->
 
</form>
        </div>
</div>