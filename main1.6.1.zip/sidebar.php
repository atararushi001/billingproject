<nav class="navbar navbar-inverse fixed-top" id="sidebar-wrapper" role="navigation">
      <ul class="nav sidebar-nav">
        <div class="sidebar-header">
          <div class="sidebar-brand">
            <a href="index.php">
              <img src="assets/img/logo.png" alt="" srcset="" style="height: 40px; ">
            </a>
          </div>
        </div>
        <!-- <li><a href="#home">Home</a></li> -->

        <li class="dropdown">
          <a href="#works" class="dropdown-toggle" data-toggle="dropdown">Package Slip <span class="caret"></span></a>
          <ul class="dropdown-menu animated fadeInLeft" role="menu">
            <div class="dropdown-header" >Package Slip</div>
            <li><a href="index.php?view=Packageslipfrom">Add</a></li>
            <li><a href="index.php?view=Packagesliplist">View</a></li>
          </ul>
        </li>

        <li class="dropdown">
          <a href="#works" class="dropdown-toggle" data-toggle="dropdown">Invoice Slip<span class="caret"></span></a>
          <ul class="dropdown-menu animated fadeInLeft" role="menu">
            <div class="dropdown-header">Invoice Slip</div>
            <li><a href="index.php?view=Invoiceslipform">Add</a></li>
            <li><a href="index.php?view=invoicesliplist">View</a></li>
          </ul>
        </li>
        <li><a href="index.php?view=logout">logout</a></li> 
      </ul>
    </nav>