<?php 
session_unset();
echo("<script>location.href = 'index.php';</script>");
// header("Location: index.php"); 
?>